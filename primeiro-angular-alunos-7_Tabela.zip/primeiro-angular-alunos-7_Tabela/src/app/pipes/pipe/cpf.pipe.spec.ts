import { CpfPipe } from './cpf.pipe';

describe('CpfPipe', () => {
  it('create an instance', () => {
    const pipe = new CpfPipe();
    expect(pipe).toBeTruthy();
  });
});
